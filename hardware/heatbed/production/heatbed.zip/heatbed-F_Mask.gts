G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.2*
G04 #@! TF.CreationDate,2025-12-05T17:15:57-05:00*
G04 #@! TF.ProjectId,heatbed,68656174-6265-4642-9e6b-696361645f70,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.2) date 2025-12-05 17:15:57*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10RoundRect,0.250000X0.262500X0.450000X-0.262500X0.450000X-0.262500X-0.450000X0.262500X-0.450000X0*%
%ADD11C,4.000000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,R1*
X166362500Y-194187500D03*
X168187500Y-194187500D03*
G04 #@! TD*
G04 #@! TO.C,R2*
X168187500Y-248464250D03*
X166362500Y-248464250D03*
G04 #@! TD*
D11*
G04 #@! TO.C,J2*
X172300000Y-250014250D03*
G04 #@! TD*
G04 #@! TO.C,J1*
X162250000Y-250014250D03*
G04 #@! TD*
M02*
