G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.6*
G04 #@! TF.CreationDate,2025-11-25T02:17:48-05:00*
G04 #@! TF.ProjectId,heatbed,68656174-6265-4642-9e6b-696361645f70,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.6) date 2025-11-25 02:17:48*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,4.000000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,J2*
X176575000Y-58475000D03*
G04 #@! TD*
G04 #@! TO.C,J1*
X151525000Y-58475000D03*
G04 #@! TD*
M02*
